<?php
    header('Content-Type: text/html; charset=utf-8'); 
    echo"
        <style>
             body{
                 background-color: rgb(211, 177, 243);
                text-align: center;
                margin-top: 50px;
            }
        </style>
    
    ";
    //variaveis 
    $total = 0;
    $preco = 2800;
    $cont = 1;
    $juros = 2.29;

    //teste se preencheu o formulario
    if(isset($_POST["parcelas"]) && !empty($_POST["parcelas"])){

        $parcela = $_POST["parcelas"];

        switch($parcela){
            case "1":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br><br> Valor da divisão: ".$total;
            break;

            case "2":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$" .$preco;
                echo "<br><br> Valor da divisão: ". $total;
            break;

            case "3":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br><br> Valor da divisão: ". $total;
            break;

            case "4":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br><br> Valor da divisão: ". $total;
            break;

            case "5":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br><br> Valor da divisão: ". $total;
            break;

            case "6":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br><br> Valor da divisão: ". $total;
            break;

            case "7":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br><br> Valor da divisão: ". $total;
            break;

            case "8":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br> <br>Preço: R$".$preco;
                echo "<br> <br>Valor da divisão: ". $total;
            break;


            case "9":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br> <br>Preço: R$".$preco;
                echo "<br> <br>Valor da divisão: ". $total;
            break;


            case "10":
                $total = $preco /  $parcela;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br> <br>Preço: R$".$preco;
                echo "<br><br> Valor da divisão: ". $total;
            break;

            case "11":
                $total = $preco /  $parcela * $juros;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br> <br>Valor com o juros: R$ ".$total;
            break;

            case "12":
                $total = $preco /  $parcela * $juros;
                echo"<br> Produto: Celular Samsung A21";
                echo"<br><br> Preço: R$".$preco;
                echo "<br><br> Valor com o juros: R$ ".$total;
            break;

        }
        while($cont<=$parcela){
            echo "<br><br>Valor das parcelas: ".$total;
            $cont++;
        }
    }
    else{
        header("location:index.html");
    }





























?>